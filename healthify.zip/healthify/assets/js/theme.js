(function ($) {
    'use strict';

    /*---WOW active js ---- */
    new WOW().init();



})(jQuery);




    /*----------
    Footer Toggle
    ----------*/
    function footerExplanCollapse() {
        $(".footer-top h5").addClass('toggled');
        $('.footer-top .toggled').on('click',function(e){
            e.preventDefault();
            if ($(window).width() < 992) {
                $(this).toggleClass('active');
                $(this).parent().find('ul').toggleClass('active').toggle('slow');
            }
        });
    }

    $(document).ready(function() {
        // footer
        footerExplanCollapse();
    });





$(document).ready(function () {
    $(".currency_name").click(function () {
        $(".currency_list").slideToggle("slow");
    });
});







// window.onscroll = function() {myFunction()};

// var navbar = document.getElementById("navbar");
// var sticky = navbar.offsetTop;

// function myFunction() {
//   if (window.pageYOffset >= sticky) {
//     navbar.classList.add("sticky")
//   } else {
//     navbar.classList.remove("sticky");
//   }
// }


















